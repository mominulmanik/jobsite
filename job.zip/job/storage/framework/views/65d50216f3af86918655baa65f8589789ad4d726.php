<!DOCTYPE html>
<html lang="en">
<!-- header -->
<?php echo $__env->make('applicant.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
	<!-- navbar -->
	<?php echo $__env->make('applicant.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="container">
	  <h2>Job Circular</h2>
	  <?php if($job_post): ?>
	    <?php $__currentLoopData = $job_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <a href="jobdetails\<?php echo e($job_post->id); ?>">
	      <div class="panel panel-default">
	        <div class="panel-heading">
	          <strong><?php echo e($job_post->bussiness_name); ?></strong>
	          <p><strong><?php echo e($job_post->job_title); ?></strong></div></p>
	        <div class="panel-body">
	          <strong>Salary:</strong><p><?php echo e($job_post->salary); ?></p>
	          <strong>Job Location:</strong><p><?php echo e($job_post->job_location); ?></p>
	          <strong>Country:</strong><p><?php echo e($job_post->country); ?></p>
	        </div>
	      </div>
	    </a>
	   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  
	  <?php else: ?> 
	    <div class="panel panel-default">
	    <div class="panel-heading">No job posted</div>
	    </div>
	  
	  <?php endif; ?>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\job\resources\views/applicant/index.blade.php ENDPATH**/ ?>