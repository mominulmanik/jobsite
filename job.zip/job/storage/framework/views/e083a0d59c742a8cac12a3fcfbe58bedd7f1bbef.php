<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('company.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('company.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
  <h2>Edit Job Info</h2>
  
    <?php $__currentLoopData = $job_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
      <div class="panel panel-default">
        <div class="panel-body">
          <form action="/upload/<?php echo e($applicants->a_id); ?>" method="POST" enctype="multipart/form-data">

            <?php echo csrf_field(); ?>
              <div class="form-group row">
                  <label for="first_name" class="col-md-2 "><?php echo e(('Job Title')); ?></label>

                  <div class="col-md-4">
                      <input type="text" name="job_title" id="job_title" class="form-control" value="<?php echo e($job_details->job_title); ?>">
          </div>
              </div>
              <div class="form-group row">
                  <label for="last_name" class="col-md-2 "><?php echo e(('Job Description')); ?></label>

                  <div class="col-md-4">
                      <input type="text" name="job_description" id="job_description" class="form-control" value="<?php echo e($job_details->job_description); ?>">
          </div>
              </div>
              <div class="form-group row">
                  <label for="email" class="col-md-2 "><?php echo e(('Salary')); ?></label>

                  <div class="col-md-4">
                      <input type="text" name="salary" id="salary" class="form-control" value="<?php echo e($job_details->salary); ?>">
          </div>
              </div>
              <div class="form-group row">
                  <label for="image" class="col-md-2 "><?php echo e(('Job Location')); ?></label>

                  <div class="col-md-4">
                      <input type="text" name="job_location" id="job_location" class="form-control" value="<?php echo e($job_details->job_location); ?>">
                      <div id="photo">
                      <!-- <img src="1111.jpg" width="100px" height="100px"> -->
                    </div>
          </div>
              </div>
              <div class="form-group row">
                  <label for="cv" class="col-md-2 "><?php echo e(('Country')); ?></label>

                  <div class="col-md-4">
                      <input type="text" name="country" id="country" class="form-control" value="<?php echo e($job_details->country); ?>">

          </div>
              </div>
              <div class="form-group row">
                  <label for="skill" class="col-md-2 "><?php echo e(__('Skills')); ?></label>

                  <div class="col-md-4">
                      
          </div>
              </div>
              <div class="form-group">
          <button type="submit" class="btn btn-success">Upload</button>
        </div>
        </form>
      </div>
    </div>
</body>
<script type="text/javascript">
  function edit(id)
  {
    var url="<?php echo e(route('jobposts.edit',"+id+")); ?>";
    $.ajax({
           type:'GET',
           url:url,
           data:'',
           success:function(data) {
              
           }
        });
  }
</script>

</html>
<?php /**PATH D:\xampp\htdocs\job\resources\views/company/edit.blade.php ENDPATH**/ ?>