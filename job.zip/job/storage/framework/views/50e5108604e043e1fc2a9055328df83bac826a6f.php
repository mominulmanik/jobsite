<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('company.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('company.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
   <div class="panel panel-default">
        <div class="panel-heading"><strong>All job posted from this company</strong> </div>

        <?php $__currentLoopData = $job_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="panel-body">
          	<strong>Job Title:</strong>
          	<?php echo e($job_post->job_title); ?>

          	
          	<div id="tables<?php echo e($job_post->id); ?>"></div>
          	<button type="button" onclick="gets('gettable/<?php echo e($job_post->id); ?>','<?php echo e($job_post->id); ?>')"   class="btn btn-info" style="float: right;">Show Applicants</button>
		 
        </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    
  </div>

</body>
<script>
         function gets(url1,id) {

            $.ajax({
               type:'GET',
               url:url1,
               data:'',
               success:function(data) {
                  $("#tables"+id).append(data);
               }
            });
         }
         function resume(){
         	
         }
      </script>
</html>
<?php /**PATH D:\xampp\htdocs\job\resources\views/company/test.blade.php ENDPATH**/ ?>