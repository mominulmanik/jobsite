<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('company.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('company.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <?php if(Session::get('success')): ?>
  <div class="alert alert-success">
        <p><?php echo e(Session::get('success')); ?></p>
    </div>
    <?php endif; ?>
    <a class="btn btn-success " data-toggle="modal" data-target="#myModal"  style="float: right;">Post New Job</a>
  <h2>Posted Job</h2>
  <?php if($job_post): ?>
    <?php $__currentLoopData = $job_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('jobposts.show',$job_post->id)); ?>">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong><?php echo e($job_post->bussiness_name); ?></strong>
          <p><strong><?php echo e($job_post->job_title); ?></strong></p></div>
        <div class="panel-body">
          <strong>Salary:</strong><p><?php echo e($job_post->salary); ?></p>
          <strong>Job Location:</strong><p><?php echo e($job_post->job_location); ?></p>
          <strong>Country:</strong><p><?php echo e($job_post->country); ?></p>
        </div>
      </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  <?php else: ?> 
    <div class="panel panel-default">
    <div class="panel-heading">No job posted</div>
    </div>
  
  <?php endif; ?>
  <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Post new job</h4>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('jobposts.store')); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

      
      <input type="hidden" name="company_id" value="<?php echo e(Session::get('company_id')); ?>" >
      
     <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Job title:</strong>
                <input type="text" name="job_title" class="form-control" placeholder="Job tile">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Job description:</strong>
                <textarea type="text" class="form-control" name="job_description" placeholder="Job description"></textarea>
                
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Salary:</strong>
                <input type="text" class="form-control" name="salary" placeholder="Salary">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Job location:</strong>
                <input type="text" class="form-control" name="job_location" placeholder="Job location">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Country:</strong>
                <input type="text" class="form-control" name="country" placeholder="Country">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
   
</form>
      </div>
      
    </div>

  </div>
</div>              

</body>

</html>
<?php /**PATH D:\xampp\htdocs\job\resources\views/company/add_jobpost.blade.php ENDPATH**/ ?>