<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('applicant.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('applicant.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
	<!-- Alert message -->
	<?php if(Session::get('success')): ?>
	<div class="alert alert-success">
        <p><?php echo e(Session::get('success')); ?></p>
    </div>
    <?php endif; ?>
    <?php if(Session::get('error')): ?>
    <div class="alert alert-success">
        <p><?php echo e(Session::get('error')); ?></p>
    </div>
    <?php endif; ?>
    <!-- panel start -->
   	<div class="panel panel-default">
   		<!-- panel header -->
        <div class="panel-heading">
        	<strong><?php echo e(Auth::user()->name); ?> Profile</strong>
        </div>
        <!-- end panel header -->
        <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicants): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- panel body start -->
        <div class="panel-body">
        	<!-- show and update profile form start -->
        	<form action="/upload/<?php echo e($applicants->a_id); ?>" method="POST" enctype="multipart/form-data">

            <?php echo csrf_field(); ?>
            	<div class="form-group row">
	                <label for="first_name" class="col-md-2 "><?php echo e(__('First name')); ?></label>

	                <div class="col-md-4" id="first_name">
	                    <?php echo e($applicants->first_name); ?>

	                    <a onclick="change('first_name','<?php echo e($applicants->first_name); ?>')">Change</a>
	                    <input type="hidden" name="first_name" value="<?php echo e($applicants->first_name); ?>">
					</div>
            	</div>
            	<div class="form-group row">
	                <label for="last_name" class="col-md-2 "><?php echo e(__('last name')); ?></label>

	                <div class="col-md-4" id="last_name">
	                    <?php echo e($applicants->last_name); ?>

	                    <a onclick="change('last_name','<?php echo e($applicants->last_name); ?>')">Change</a>
	                    <input type="hidden" name="last_name" value="<?php echo e($applicants->last_name); ?>">
					</div>
            	</div>
            	<div class="form-group row">
	                <label for="email" class="col-md-2 "><?php echo e(__('Email')); ?></label>

	                <div class="col-md-4" id="email">
	                    <?php echo e($applicants->email); ?>

	                    <a onclick="change('email','<?php echo e($applicants->email); ?>')">Change</a>
	                    <input type="hidden" name="email" value="<?php echo e($applicants->email); ?>">
					</div>
            	</div>
            	<div class="form-group row">
	                <label for="image" class="col-md-2 "><?php echo e(__('Applicant Photo')); ?></label>

	                <div class="col-md-4" id="image">
	                    <?php if($applicants->image): ?>
	                    
	                     <img src="images/<?php echo e($applicants->image); ?>" width="100px" height="100px">
	                     <a onclick="change('image')">Change</a> 
	                     
	                     <?php else: ?>
	                     <input type="file" name="image" id="image" class="form-control" >
	                     <?php endif; ?>
	                	
					</div>
            	</div>
            	<div class="form-group row">
	                <label for="resume" class="col-md-2 "><?php echo e(__('Applicant Resume')); ?></label>

	                <div class="col-md-4" id="resume">
	                    <?php if($applicants->resume): ?>
	                    <iframe src="pdf/<?php echo e($applicants->resume); ?>" frameborder="0" style="width:300px; height:100px;"  ></iframe><?php echo e($applicants->resume); ?>

	                     <a onclick="change('resume')">Change</a> 
	                     
	                     <?php else: ?>
	                     <input type="file" name="resume" id="resume" class="form-control" >
	                     <?php endif; ?>

					</div>
            	</div>
            	<div class="form-group row">
	                <label for="skill" class="col-md-2 "><?php echo e(__('Skills')); ?></label>

	                <div class="col-md-4" id="skill">
	                    <input type="text" name="skill" id="skill" class="form-control" value="<?php echo e($applicants->skills); ?>">
					</div>
            	</div>
            	<div class="form-group">
					<button type="submit" class="btn btn-success">Update</button>
				</div>
        	</form>
        <!-- form end -->
        </div>
        <!-- end panel body -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- panel end -->
</div>
</body>
<?php echo $__env->make('applicant.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH D:\xampp\htdocs\job\resources\views/applicant/profile.blade.php ENDPATH**/ ?>