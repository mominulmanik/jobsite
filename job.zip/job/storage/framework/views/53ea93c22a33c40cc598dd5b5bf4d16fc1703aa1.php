<div id="footer" >
	<p style="float: center;">Copyright: Mominul Islam. 2019</p>
</div><?php /**PATH D:\xampp\htdocs\job\resources\views/applicant/layouts/footer.blade.php ENDPATH**/ ?>