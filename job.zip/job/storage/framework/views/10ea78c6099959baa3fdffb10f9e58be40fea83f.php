<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('company.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('company.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
<iframe src="pdf/1564181160.pdf" frameborder="0" style="width:600px; min-height:100px;"></iframe>
</div>
</body>
</html><?php /**PATH D:\xampp\htdocs\job\resources\views/company/resume.blade.php ENDPATH**/ ?>