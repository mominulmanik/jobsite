<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('company.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('company.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
   <?php if(Session::get('success')): ?>
  <div class="alert alert-success">
        <p><?php echo e(Session::get('success')); ?></p>
    </div>
    <?php endif; ?>
  <h2>Job Details</h2>
  
    <?php $__currentLoopData = $job_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
      <div class="panel panel-default">
        <div class="panel-body">
            <form action="<?php echo e(route('jobposts.update',$job_details->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
              <strong>Job Title</strong>
              <div id="job_title">
              <?php echo e($job_details->job_title); ?>

              <input type="hidden" name="job_title" id="job_title" value="<?php echo e($job_details->job_title); ?>">
              <a onclick="changedetails('job_title','<?php echo e($job_details->job_title); ?>')">Edit</a>
              </div>
              <strong>Job Description</strong>
              <div id="job_description">
                <p><?php echo e($job_details->job_description); ?></p>
                <a onclick="changedetails('job_description','<?php echo e($job_details->job_description); ?>')">Edit</a>
                <input type="hidden" name="job_description" id="job_description" value="<?php echo e($job_details->job_description); ?>">
              </div>
              <strong>Salary</strong>
              <div id="salary">
                <p><?php echo e($job_details->salary); ?></p>
                <a onclick="changedetails('salary','<?php echo e($job_details->salary); ?>')">Edit</a>
                <input type="hidden" name="salary" id="salary" value="<?php echo e($job_details->salary); ?>">
              </div>
              <strong>Job Location</strong>
              <div id="job_location">
                <p><?php echo e($job_details->job_location); ?></p>
                <a onclick="changedetails('job_location','<?php echo e($job_details->job_location); ?>')">Edit</a>
                <input type="hidden" name="job_location" id="job_location" value="<?php echo e($job_details->job_location); ?>">
              </div>
              <strong>Country</strong>
              <div id="country">
                <p><?php echo e($job_details->country); ?></p>
                <a onclick="changedetails('country','<?php echo e($job_details->country); ?>')">Edit</a>
                <input type="hidden" name="country" id="country" value="<?php echo e($job_details->country); ?>">
              </div>
              <button type="submit" class="btn btn-primary" style="float: right; margin-left: 5px;">Update Post</button> 
          </form>
          <form action="<?php echo e(route('jobposts.destroy',$job_details->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger" style="float: right;">Delete Post</button>
          </form>
        
        
        </div>
      </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
<script type="text/javascript">
  
</script>

</html>
<?php /**PATH D:\xampp\htdocs\job\resources\views/company/jobdetails.blade.php ENDPATH**/ ?>