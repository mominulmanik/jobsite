<!DOCTYPE html>
<html lang="en">
<!-- head -->
<?php echo $__env->make('applicant.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
	<!-- Navbar -->
	<?php echo $__env->make('applicant.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="container">
		<!-- table for showing applied job -->
		<table class="table table-bordered" style="width:50%">
		  <thead>
		    <th>Name</th>
		    <th>Bussiness name</th>
		    <th>email</th>
		    <th>Job Title</th>
		    <th>Salary</th>
		    <th>Action</th>
		  </thead>
		  <tbody>
		  <?php $__currentLoopData = $applied_job; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applied_job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  	<tr>
		        <td><?php echo e($applied_job->first_name.$applied_job->last_name); ?></td>
		        <td><?php echo e($applied_job->bussiness_name); ?></td>
		        <td><?php echo e($applied_job->email); ?></td>
		        <td><?php echo e($applied_job->job_title); ?></td>
		        <td><?php echo e($applied_job->salary); ?></td>
		        <td><a href="jobdetails\<?php echo e($applied_job->id); ?>"> Details</a></td>
		    </tr>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  </tbody>
		</table>
		<!-- end table -->

	</div>
</body>
</html><?php /**PATH D:\xampp\htdocs\job\resources\views/applicant/applied_job.blade.php ENDPATH**/ ?>