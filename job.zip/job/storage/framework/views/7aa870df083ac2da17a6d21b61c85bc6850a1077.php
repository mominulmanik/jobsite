<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('applicant.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('applicant.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
	<?php if(Session::get('success')): ?>
	<div class="alert alert-success">
        <p><?php echo e(Session::get('success')); ?></p>
    </div>
    <?php endif; ?>
   	<h2>Job Details</h2>
  
    <?php $__currentLoopData = $job_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong><?php echo e($job_details->bussiness_name); ?></strong>
          <p><strong><?php echo e($job_details->job_title); ?></strong></p>
        </div>
        <div class="panel-body">
          <strong>Job details:</strong><p><?php echo e($job_details->job_description); ?></p>
          <strong>Salary:</strong><p><?php echo e($job_details->salary); ?></p>
          <strong>Job Location:</strong><p><?php echo e($job_details->job_location); ?></p>
          <strong>Country:</strong><p><?php echo e($job_details->country); ?></p>
        <a href="/job_apply/<?php echo e($job_details->id); ?>" class="btn btn-primary" style="float: right; margin-left: 5px;">Apply</a> 
        
        </div>
      </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>

</html>
<?php /**PATH D:\xampp\htdocs\job\resources\views/applicant/jobdetails.blade.php ENDPATH**/ ?>