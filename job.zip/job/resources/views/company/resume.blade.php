<!DOCTYPE html>
<html lang="en">
@include('company.layouts.head')
<body>
@include('company.layouts.nav')
<div class="container">
<iframe src="pdf/1564181160.pdf" frameborder="0" style="width:600px; min-height:100px;"></iframe>
</div>
</body>
</html>